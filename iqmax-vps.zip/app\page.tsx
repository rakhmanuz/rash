import { PremiumHero } from '@/components/landing/PremiumHero'

export default function Home() {
  return (
    <div className="w-full overflow-hidden">
      <PremiumHero />
    </div>
  )
}
